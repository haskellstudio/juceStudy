/*
  ==============================================================================

  This is an automatically generated GUI class created by the Projucer!

  Be careful when adding custom code to these files, as only the code within
  the "//[xyz]" and "//[/xyz]" sections will be retained when the file is loaded
  and re-saved.

  Created with Projucer version: 5.0.2

  ------------------------------------------------------------------------------

  The Projucer is part of the JUCE library - "Jules' Utility Class Extensions"
  Copyright (c) 2015 - ROLI Ltd.

  ==============================================================================
*/

//[Headers] You can add your own extra header files here...
//[/Headers]

#include "RightComponent.h"


//[MiscUserDefs] You can add your own user definitions and misc code here...
#include "ComponentList.h"
#include "loaddll.h"
#include "libdasm.h"
//[/MiscUserDefs]

//==============================================================================
RightComponent::RightComponent (String s)
{
    //[Constructor_pre] You can add your own custom stuff here..
    //[/Constructor_pre]

    addAndMakeVisible (textEditor = new TextEditor ("new text editor"));
    textEditor->setMultiLine (true);
    textEditor->setReturnKeyStartsNewLine (true);
    textEditor->setReadOnly (false);
    textEditor->setScrollbarsShown (true);
    textEditor->setCaretVisible (true);
    textEditor->setPopupMenuEnabled (true);
    textEditor->setText (String());


    //[UserPreSize]
    //[/UserPreSize]

    setSize (600, 400);


    //[Constructor] You can add your own custom stuff here..
    //[/Constructor]
}

RightComponent::~RightComponent()
{
    //[Destructor_pre]. You can add your own custom destruction code here..
    //[/Destructor_pre]

    textEditor = nullptr;


    //[Destructor]. You can add your own custom destruction code here..
    //[/Destructor]
}

//==============================================================================
void RightComponent::paint (Graphics& g)
{
    //[UserPrePaint] Add your own custom painting code here..
    //[/UserPrePaint]
		g.fillAll(Colour(0xff323e44));
   
    //[UserPaint] Add your own custom painting code here..
    //[/UserPaint]
}

void RightComponent::resized()
{
    //[UserPreResize] Add your own custom resize code here..
    //[/UserPreResize]

    textEditor->setBounds (80, 24, 1072, 816);
    //[UserResized] Add your own custom resize handling here..

	auto r = getLocalBounds();
	textEditor->setBounds(r);
	//FlexBox masterbox;
	//masterbox.flexDirection = FlexBox::Direction::column;// column;// : FlexBox::Direction::row;
	//masterbox.alignItems = FlexBox::AlignItems::stretch;
	//masterbox.alignContent = FlexBox::AlignContent::center;
	//masterbox.flexWrap = juce::FlexBox::Wrap::wrap;
	//masterbox.justifyContent = FlexBox::JustifyContent::center;



	//int num = getNumChildComponents();
	//for (auto i = 0; i < num; i++)
	//{
	//	auto c = getChildComponent(i);
	//	if (c)
	//	{
	//		masterbox.items.add(FlexItem(1, 1).withFlex(1).withMargin(10).withMinHeight(300).withMinWidth(300));
	//		auto& flexitem = masterbox.items.getReference(masterbox.items.size() - 1);
	//		flexitem.associatedComponent = c;
	//	}
	//}
	//masterbox.performLayout(r);
    //[/UserResized]
}



//[MiscUserCode] You can add your own definitions of your custom methods or any other code here...



// 100MB  100000000
BYTE tmpbuf[100000000] = { 0 };


juce::String test(juce::String processname, juce::String modulename, juce::String jobname , BYTE  check_code_cmd[], int check_code_len)
{
	if (EnableDebugPriv(SE_DEBUG_NAME))
	{
		return juce::String("Fail add privilege ") + processname;
	}

	DWORD pid = GetProcessID(processname.getCharPointer().getAddress()/*"srcds.exe"*/);
	if (!pid) {
		
		return juce::String("Fail to open process ") + processname;
	}
	MODULEENTRY32 ME32;
	if (!GetModuleInfo(ME32, modulename.getCharPointer().getAddress(), pid)) {

		return juce::String("Fail GetModuleInfo ") + " " + processname + " " + modulename +  jobname;
	}

	DWORD base = DWORD(ME32.modBaseAddr) ;

	DWORD size = ME32.modBaseSize;
	HANDLE hcsgo;
	hcsgo = OpenProcess(PROCESS_ALL_ACCESS, false, pid);
	if (hcsgo == NULL) {;
		return juce::String("Fail OpenProcess ") + jobname;
	}

	SIZE_T readByte = 0;
	BOOL b = ReadProcessMemory(hcsgo, LPCVOID(base), tmpbuf, size, &readByte);
	if (!b)
	{
		return juce::String("Fail ReadProcessMemory ") + jobname;
	}
	
	int cmdAddr = (DWORD)memmem((char*)tmpbuf, size, (char*)check_code_cmd, check_code_len);
	if (!cmdAddr)
	{
		return juce::String("Fail find key code ") + jobname;
	}

	int game_cmdAddr = cmdAddr - DWORD(tmpbuf) + base;

	INSTRUCTION inst;
	char szinst[128];
	byte *pbin = (byte*)cmdAddr;
	byte *offset = (byte*)game_cmdAddr;
	juce::String ins;
	do
	{
		int ret0 = get_instruction(&inst, pbin, MODE_32);
		if (ret0 == 0)
			break;
		pbin += ret0;
		if (!get_instruction_string(&inst, FORMAT_INTEL, (DWORD)offset, szinst, sizeof(szinst)))
		{
			break;
		}
		offset += ret0;
		printf("code is :: %s\n", szinst);
		ins = ins + juce::String(szinst) + "\r\n";
	} while (pbin  < (byte*)cmdAddr + 20);


	return jobname + " 0x" + juce::String::toHexString(game_cmdAddr) + "\r\n" + ins;

}

class DemoThread : public RightComponent,
	public Thread
{
public:
	DemoThread(String s)
		: Thread("Juce Demo Thread"), _s(s),RightComponent(s)
	{
		interval = Random::getSystemRandom().nextInt(50) + 6;

		// give the threads a random priority, so some will move more
		// smoothly than others..
		startThread(Random::getSystemRandom().nextInt(3) + 3);
	}

	~DemoThread()
	{
		// allow the thread 2 seconds to stop cleanly - should be plenty of time.
		stopThread(2000);
	}

	void run() override
	{
		// this is the code that runs this thread - we'll loop continuously,
		// updating the coordinates of our blob.

		// threadShouldExit() returns true when the stopThread() method has been
		// called, so we should check it often, and exit as soon as it gets flagged.
		while (!threadShouldExit())
		{
			// sleep a bit so the threads don't all grind the CPU to a halt..
			wait(interval);
			//wait(1000);
			// because this is a background thread, we mustn't do any UI work without
			// first grabbing a MessageManagerLock..
			

			if (_s == "2")
			{
				BYTE check_code_log[] = { 0x8B, 0x45, 0x08, 0x83, 0xEC, 0x14, 0x53 };
				auto r1 = test("srcds.exe", "tier0.dll", "StartHookLog", check_code_log, sizeof(check_code_log));






				BYTE  check_code_csgo_event[] = { 0x83, 0xEC, 0x0C, 0x53, 0x8B, 0xD9, 0x56, 0x57, 0x89, 0x5C, 0x24 };
				auto r2 = test("srcds.exe", "engine.dll", "csgo_event_addr", check_code_csgo_event, sizeof(check_code_csgo_event));

				BYTE check_code_chat[] = { 0x83, 0xC4, 0x18, 0xa8, 0x01 };
				auto r3 = test("srcds.exe", "server.dll", "check_code_chat", check_code_chat, sizeof(check_code_chat));

				BYTE check_code_vote[] = { 0x55, 0x8B, 0xEC, 0x8B, 0x55, 0x0C, 0x53, 0x56, 0x57, 0x8B, 0xF9, 0x33, 0xF6 };
				auto r4 = test("srcds.exe", "engine.dll", "startHookVote", check_code_vote, sizeof(check_code_vote));
				const MessageManagerLock mml(Thread::getCurrentThread());
				if (!mml.lockWasGained())  // if something is trying to kill this job, the lock
					return;                 // will fail, in which case we'd better return..

				msgbox(r1);
				msgbox(r2);
				msgbox(r3);
				msgbox(r4);											// now we've got the UI thread locked, we can mess about with the components
				String s = r1 + r2 + r3 + r4;
				if (s.contains("Fail"))
				{
					errorBackground(true);
				}
				else
				{
					errorBackground(false);
				}

			}
			else if (_s == "0")
			{
				BYTE check_code_rank_score[8] = { 0x8B, 0x70, 0x70, 0x85, 0xc9, 0x74, 0x07, 0x8B };
				auto r1 = test("dota2.exe", "client.dll", "getRankScore", check_code_rank_score, sizeof(check_code_rank_score));
				

				BYTE check_code_steamID[7] = { 0x68, 0x40, 0x42, 0x0F, 0x00, 0x6a, 0x01 };
				auto r2 = test("dota2.exe", "client.dll", "getSteamID", check_code_steamID, sizeof(check_code_steamID));
				

				BYTE  check_code_send[] = { 0x8B, 0x49, 0x04, 0xFF, 0x75, 0x0C, 0xFF, 0x75, 0x08, 0x8B, 0x01, 0x6A, 0x00, 0xFF, 0x10 };
				auto r3 = test("dota2.exe", "steamclient.dll", "check_code_send", check_code_send, sizeof(check_code_send));
				


				BYTE  check_code_recv[] = { 0x8B, 0x49, 0x04, 0xFF, 0x75, 0x10, 0xFF, 0x75, 0x0C, 0x8B, 0x01, 0xFF, 0x75, 0x08, 0x6A, 0x00, 0xFF, 0x50, 0x08 };
				auto r4 = test("dota2.exe", "steamclient.dll", "check_code_recv", check_code_recv, sizeof(check_code_recv));

				const MessageManagerLock mml(Thread::getCurrentThread());
				if (!mml.lockWasGained()) 
					return;
				msgbox(r1);
				msgbox(r2);
				msgbox(r3);
				msgbox(r4);
				String s = r1 + r2 + r3 + r4;
				if (s.contains("Fail"))
				{
					errorBackground(true);
				}
				else
				{
					errorBackground(false);
				}
				
			}
			
			signalThreadShouldExit();

		}
	}

private:
	int interval;
	String _s;

	JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(DemoThread)
};



static ComponentList<DemoThread> dota2((const String)("Dota2"));
static ComponentList<DemoThread> csgo((const String)("CSGO"));
/*
#include "libdasm.h"
#include "windows.h"


int getCodeLen(byte* code)
{
int curlen = 0;
INSTRUCTION d;
while (curlen < 5)
{
int len = get_instruction(&d, code + curlen, MODE_32);
if (len <= 0)
return 0;
else
{
curlen += len;
}
}
return curlen;
}

int _tmain(int argc, _TCHAR* argv[])
{

byte bin[] = {
0xE8, 0x93, 0xBC, 0xFF, 0xFF, 0xC7, 0x00, 0x0C, 0x00, 0x00,
0x00, 0xE8, 0x75, 0xBC, 0xFF, 0xFF, 0xC7, 0x00, 0x08, 0x00,
0x00, 0x00, 0xE9, 0x76, 0x01, 0x00, 0x00
};


INSTRUCTION inst;
char szinst[128];
byte *pbin = bin;
byte *offset = (byte*)0x56ED1250;
do
{
int ret0 = get_instruction(&inst, pbin, MODE_32);
pbin += ret0;
if (!get_instruction_string(&inst, FORMAT_INTEL, (DWORD)offset, szinst, sizeof(szinst)))
{
puts("err : can't to string???");
}
offset += ret0;
printf("code is :: %s\n", szinst);
} while (pbin < bin + sizeof(bin));



printf("%d \n", getCodeLen(bin));
return 0;
}



*/


//[/MiscUserCode]


//==============================================================================
#if 0
/*  -- Projucer information section --

    This is where the Projucer stores the metadata that describe this GUI layout, so
    make changes in here at your peril!

BEGIN_JUCER_METADATA

<JUCER_COMPONENT documentType="Component" className="RightComponent" componentName=""
                 parentClasses="public Component" constructorParams="String s"
                 variableInitialisers="" snapPixels="8" snapActive="1" snapShown="1"
                 overlayOpacity="0.330" fixedSize="0" initialWidth="600" initialHeight="400">
  <BACKGROUND backgroundColour="ff323e44"/>
  <TEXTEDITOR name="new text editor" id="805cca6952b15974" memberName="textEditor"
              virtualName="" explicitFocusOrder="0" pos="80 24 1072 816" initialText=""
              multiline="1" retKeyStartsLine="1" readonly="0" scrollbars="1"
              caret="1" popupmenu="1"/>
</JUCER_COMPONENT>

END_JUCER_METADATA
*/
#endif


//[EndFile] You can add extra defines here...
//[/EndFile]
