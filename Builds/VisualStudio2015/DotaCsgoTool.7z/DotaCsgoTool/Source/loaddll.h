#include <windows.h>
#include <tlhelp32.h>
#include <stdio.h>

#ifndef FUN_H
#define FUN_H

char * memmem(const char *target, unsigned long tlen, const char *search, unsigned long slen);




int EnableDebugPriv(const char * name);  //��������ΪDEBUGȨ��


BOOL InjectDllHandle(const char *DllFullPath, HANDLE hProcessHandle);//ע�뺯��



BOOL InjectDll(const char *DllFullPath, const DWORD dwRemoteProcessId); //ע�뺯��

DWORD GetProcessID(char *ProcessName);  //��ý���PID





bool GetProcessInfo(const char *exeName, /*OUT*/PROCESS_INFORMATION *processInfo)
;


bool GetModuleInfo(const char *exeName, const char *moduleName, DWORD dwProcessId
);




bool GetModuleInfo(MODULEENTRY32 &ME32, const char *moduleName, DWORD dwProcessId
);

	
#endif