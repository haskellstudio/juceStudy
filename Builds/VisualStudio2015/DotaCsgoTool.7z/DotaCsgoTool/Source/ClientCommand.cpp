/*
  ==============================================================================

  This is an automatically generated GUI class created by the Projucer!

  Be careful when adding custom code to these files, as only the code within
  the "//[xyz]" and "//[/xyz]" sections will be retained when the file is loaded
  and re-saved.

  Created with Projucer version: 5.0.2

  ------------------------------------------------------------------------------

  The Projucer is part of the JUCE library - "Jules' Utility Class Extensions"
  Copyright (c) 2015 - ROLI Ltd.

  ==============================================================================
*/

//[Headers] You can add your own extra header files here...
//[/Headers]

#include "ClientCommand.h"


//[MiscUserDefs] You can add your own user definitions and misc code here...
#include "ComponentList.h"
#include "loaddll.h"


//[/MiscUserDefs]

//==============================================================================
ClientCommand::ClientCommand (String s)
{
    //[Constructor_pre] You can add your own custom stuff here..
    //[/Constructor_pre]

    addAndMakeVisible (textEditor = new TextEditor ("new text editor"));
    textEditor->setMultiLine (false);
    textEditor->setReturnKeyStartsNewLine (false);
    textEditor->setReadOnly (false);
    textEditor->setScrollbarsShown (true);
    textEditor->setCaretVisible (true);
    textEditor->setPopupMenuEnabled (true);
    textEditor->setText (String());


    //[UserPreSize]
	textEditor->addListener(this);
    //[/UserPreSize]

    setSize (600, 400);


    //[Constructor] You can add your own custom stuff here..
    //[/Constructor]
}

ClientCommand::~ClientCommand()
{
    //[Destructor_pre]. You can add your own custom destruction code here..
    //[/Destructor_pre]

    textEditor = nullptr;


    //[Destructor]. You can add your own custom destruction code here..
    //[/Destructor]
}

//==============================================================================
void ClientCommand::paint (Graphics& g)
{
    //[UserPrePaint] Add your own custom painting code here..
    //[/UserPrePaint]

    g.fillAll (Colour (0xff323e44));

    //[UserPaint] Add your own custom painting code here..
    //[/UserPaint]
}

void ClientCommand::resized()
{
    //[UserPreResize] Add your own custom resize code here..
    //[/UserPreResize]

    textEditor->setBounds (40, 72, 928, 160);
    //[UserResized] Add your own custom resize handling here..
	auto r = getLocalBounds();
	textEditor->setBounds(r);
    //[/UserResized]
}



//[MiscUserCode] You can add your own definitions of your custom methods or any other code here...
static ComponentList<ClientCommand> cmd((const String)("Console"));

//
//
//int _tmain(int argc, _TCHAR* argv[])
//{
//	if (argc == 3) {
//		test(argv[2]);
//	}
//
//
//	//	argc = 2;
//	//int pid = 7680;
//
//	if (argc == 2) {
//		int pid = atoi(argv[1]);
//		InjectDll("d:/csgo/csgodll.dll", pid);
//		::OutputDebugStringA("inject to ");
//		::OutputDebugStringA(argv[1]);
//	}
//	else {
//		::OutputDebugStringA("error to inject");
//		return 0;
//	}
//	char * ProcessName = "srcds.exe";
//
//	PROCESSENTRY32 pe32;
//	pe32.dwSize = sizeof(pe32);
//	//»ñµÃÏµÍ³ÄÚËùÓÐ½ø³Ì¿ìÕÕ
//	HANDLE hProcessSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
//	if (hProcessSnap == INVALID_HANDLE_VALUE)
//	{
//		printf("CreateToolhelp32Snapshot error");
//		return 0;
//	}
//	//Ã¶¾ÙÁÐ±íÖÐµÄµÚÒ»¸ö½ø³Ì
//	BOOL bProcess = Process32First(hProcessSnap, &pe32);
//	while (bProcess)
//	{
//		//±È½ÏÕÒµ½µÄ½ø³ÌÃûºÍÎÒÃÇÒª²éÕÒµÄ½ø³ÌÃû£¬Ò»ÑùÔò·µ»Ø½ø³Ìid
//		if (stricmp(pe32.szExeFile, ProcessName) == 0) {
//			if (!InjectDll("d:/csgo/csgodll.dll", pe32.th32ProcessID))
//			{
//				::OutputDebugStringA("fail to inject ");
//				printf("fail to inject");
//			}
//			else {
//				::OutputDebugStringA("sucess to inject ");
//				printf("sucess to inject");
//			}
//		}
//		//¼ÌÐø²éÕÒ
//		bProcess = Process32Next(hProcessSnap, &pe32);
//	}
//	CloseHandle(hProcessSnap);
//	printf("\n\n");
//
//
//
//
//	return 0;
//}
extern char * memmem(const char *target, unsigned long tlen, const char *search, unsigned long slen);
//{
//	char *p = NULL;
//	unsigned long i = 0;
//	char* q;
//	for (p = (char*)target; p<(target + tlen); p++)
//	{
//		q = p;
//		if (*p == search[0])
//		{
//			for (i = 0; (i<slen) && (*q == search[i]); i++)
//			{
//				q++;
//				if (i == (slen - 1))
//					return q - slen;
//			}
//		}
//	}
//	return NULL;
//}
typedef struct tagTrueAddr
{
	DWORD baseAddr;// cmd º¯ÊýµØÖ·
	char Offset[200];  // ²ÎÊý connect 127.0.0.1:234  ÀàËÆÕâ¸ö×Ö·û´®µØÖ·

}TrueAddr, *PTrueAddr;
void __stdcall addBloodCall(TrueAddr* addr)
{
	DWORD baseAddr = addr->baseAddr;
	char* baseOffset = addr->Offset;
	_asm
	{
		mov eax, baseOffset
		push 1
		push eax
		mov eax, baseAddr
		call eax
	}
}
BYTE enginedll[0x444F9A] = { 0 };


void test(const char* connectip)
{

//	::MessageBox(0, connectip, 0, 0);
	if (EnableDebugPriv(SE_DEBUG_NAME))
	{
		::OutputDebugStringA("add privilege error");
		::MessageBox(0, "fail add privilege", 0, 0);
		//return ;
	}

	DWORD pid = GetProcessID("csgo.exe");
	if (!pid) {

		::MessageBox(0, "fail pid", 0, 0);
		return;
	}
	MODULEENTRY32 ME32;
	if (!GetModuleInfo(ME32, "engine.dll", pid)) {
		::MessageBox(0, "fail GetModuleInfo", 0, 0);
		//::OutputDebugStringA("GetModuleInfo error");
		return;
	}
	else {
		//	::MessageBox(0, "success", 0, 0);
	}
	DWORD base = DWORD(ME32.modBaseAddr) + 0x1000;
	DWORD size = 0x443F9A;
	HANDLE hcsgo;
	hcsgo = OpenProcess(PROCESS_ALL_ACCESS, false, pid);
	if (hcsgo == NULL) {
		::MessageBox(0, "fail OpenProcess", 0, 0);

	}

	DWORD readByte = 0;
	BOOL b = ReadProcessMemory(hcsgo, LPCVOID(base), enginedll, 0x444F9A, &readByte);
	if (!b)
	{
		::MessageBox(0, "fail ReadProcessMemory", 0, 0);
	}


	//mov     eax, dword ptr[ecx]
	//	call    dword ptr[eax + 34]
	//	push    eax



	//1002A300 / .  55                 push    ebp
	//	1002A301 | .  8BEC               mov     ebp, esp
	//	1002A303 | .  8B0D DC335310      mov     ecx, dword ptr[105333DC];  engine.105333C0
	//	1002A309 | .  81F9 C0335310      cmp     ecx, 105333C0
	//	1002A30F | .  75 0C              jnz     short 1002A31D
	//	1002A311 | .A1 F0335310        mov     eax, dword ptr[105333F0]
	//	1002A316 | .  35 C0335310        xor     eax, 105333C0
	//	1002A31B | .EB 05              jmp     short 1002A322
	//	1002A31D | >  8B01               mov     eax, dword ptr[ecx]
	//	1002A31F | .FF50 34            call    dword ptr[eax + 34]
	//	1002A322 | >  50                 push    eax
	//	1002A323 | .A1 80325210        mov     eax, dword ptr[10523280]
	//	1002A328 | .B9 80325210        mov     ecx, 10523280
	//	1002A32D | .  8B40 1C            mov     eax, dword ptr[eax + 1C]
	//	1002A330 | .FFD0               call    eax
	//	1002A332 | .  84C0               test    al, al
	//	1002A334 | .  74 13              je      short 1002A349
	//	1002A336 | .  8B0D DC335310      mov     ecx, dword ptr[105333DC];  engine.105333C0
	//	1002A33C | .  81F9 C0335310      cmp     ecx, 105333C0
	//	1002A342 | .  74 05              je      short 1002A349
	//	1002A344 | .  8B01               mov     eax, dword ptr[ecx]
	//	1002A346 | .FF50 34            call    dword ptr[eax + 34]
	//	1002A349 | >  8B55 08            mov     edx, dword ptr[ebp + 8]
	//	1002A34C | .  33C0               xor     eax, eax
	//	1002A34E | .  3845 0C            cmp     byte ptr[ebp + C], al
	//	1002A351 | .B9 02000000        mov     ecx, 2
	//	1002A356 | .  6A 00              push    0
	//	1002A358 | .  0F45C1             cmovne  eax, ecx
	//	1002A35B | .  33C9               xor     ecx, ecx
	//	1002A35D | .  50                 push    eax
	//	1002A35E | .E8 7D2D1100        call    1013D0E0
	//	1002A363 | .  83C4 08            add     esp, 8
	//	1002A366 | .  5D                 pop     ebp
	//	1002A367  \.C2 0800            retn    8



	BYTE  check_code_cmd[] = { 0x8B, 0x01, 0xFF, 0x50, 0x34, 0x50 };
	DWORD cmdAddr = (DWORD)memmem((char*)enginedll, 0x444F9A, (char*)check_code_cmd, sizeof(check_code_cmd)/sizeof(BYTE));
	cmdAddr = cmdAddr - DWORD(enginedll) + base;
	cmdAddr = cmdAddr - 29;
	if (!cmdAddr)
	{
		::MessageBox(0, "fail cmdAddr", 0, 0);
		return;
	}


	LPVOID paramsCall = VirtualAllocEx(hcsgo, NULL, sizeof(TrueAddr), MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE); // ÉêÇë²ÎÊýÄÚ´æ
	if (paramsCall == NULL)
	{
		::MessageBox(0, "fail paramsCall VirtualAllocEx", 0, 0);

		return;
	}


	//Ä¿±ê½ø³Ì·ÖÅäº¯Êý±¾Ìå¿Õ¼ä
	LPVOID baseCall = VirtualAllocEx(hcsgo, NULL, 1000, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
	if (baseCall == NULL)
	{
		::MessageBox(0, "fail funciton VirtualAllocEx", 0, 0);

		return;
	}


	if (!WriteProcessMemory(hcsgo, baseCall, addBloodCall, 1000, NULL))
	{
		::MessageBox(0, "fail WriteProcessMemory function ", 0, 0);
		return;
	}



	TrueAddr trueAddr;
	trueAddr.baseAddr = cmdAddr;
	strcpy(trueAddr.Offset, connectip);

	if (!WriteProcessMemory(hcsgo, paramsCall, (LPCVOID)&trueAddr, sizeof(TrueAddr), NULL))
	{
		::MessageBox(0, "fail WriteProcessMemory parameter ", 0, 0);
		return;
	}


	PTrueAddr ptAddr = (PTrueAddr)paramsCall;
	HANDLE hRemoteThread = CreateRemoteThread(hcsgo, NULL, 0, (LPTHREAD_START_ROUTINE)baseCall, (LPVOID)ptAddr, 0, NULL);
	if (!hRemoteThread)
	{
		::MessageBox(0, "fail CreateRemoteThread  ", 0, 0);

		return;
	}

}
//[/MiscUserCode]


//==============================================================================
#if 0
/*  -- Projucer information section --

    This is where the Projucer stores the metadata that describe this GUI layout, so
    make changes in here at your peril!

BEGIN_JUCER_METADATA

<JUCER_COMPONENT documentType="Component" className="ClientCommand" componentName=""
                 parentClasses="public Component, public TextEditor::Listener"
                 constructorParams="String s" variableInitialisers="" snapPixels="8"
                 snapActive="1" snapShown="1" overlayOpacity="0.330" fixedSize="0"
                 initialWidth="600" initialHeight="400">
  <BACKGROUND backgroundColour="ff323e44"/>
  <TEXTEDITOR name="new text editor" id="b8b1fa0b3bc56fe6" memberName="textEditor"
              virtualName="" explicitFocusOrder="0" pos="40 72 928 160" initialText=""
              multiline="0" retKeyStartsLine="0" readonly="0" scrollbars="1"
              caret="1" popupmenu="1"/>
</JUCER_COMPONENT>

END_JUCER_METADATA
*/
#endif


//[EndFile] You can add extra defines here...
//[/EndFile]
