#include "loaddll.h"

bool GetModuleInfo(MODULEENTRY32 &ME32, const char *moduleName, DWORD dwProcessId
)
{
	HANDLE snapshotModule = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, dwProcessId);
	if (snapshotModule == INVALID_HANDLE_VALUE)
	{
		DWORD d = ::GetLastError();
		return false;
	}


	ME32.dwSize = sizeof(MODULEENTRY32);
	if (Module32First(snapshotModule, &ME32))
	{
		do
		{
			if (stricmp(ME32.szModule, moduleName) == 0)
			{

				CloseHandle(snapshotModule);
				return true;
			}
		} while (Module32Next(snapshotModule, &ME32));
	}

	CloseHandle(snapshotModule);

	return false;
}


bool GetModuleInfo(const char *exeName, const char *moduleName, DWORD dwProcessId
)
{
	HANDLE snapshotModule = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, dwProcessId);
	if (snapshotModule == INVALID_HANDLE_VALUE)
	{

		return false;
	}

	MODULEENTRY32 ME32;
	ME32.dwSize = sizeof(MODULEENTRY32);
	if (Module32First(snapshotModule, &ME32))
	{
		do
		{
			if (stricmp(ME32.szModule, moduleName) == 0)
			{

				CloseHandle(snapshotModule);

				return true;
			}
		} while (Module32Next(snapshotModule, &ME32));
	}

	CloseHandle(snapshotModule);

	return false;
}


bool GetProcessInfo(const char *exeName, /*OUT*/PROCESS_INFORMATION *processInfo)
{

	// ö�ٵ�ǰϵͳ�����н����ҳ�Ŀ�����
	//
	HANDLE snapshotProcess = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
	if (snapshotProcess == INVALID_HANDLE_VALUE)
		return false;

	PROCESSENTRY32 PE32;
	PE32.dwSize = sizeof(PROCESSENTRY32);

	bool isExist = false;
	if (Process32First(snapshotProcess, &PE32))
	{
		do
		{
			if (stricmp(PE32.szExeFile, exeName) == 0)
				isExist = true;
		} while (isExist == false && Process32Next(snapshotProcess, &PE32));
	}



	if (isExist == false)
	{

		CloseHandle(snapshotProcess);
		return false;
	}
	//
	// ö��Ŀ������������߳��ҳ�������һ�߳�
	//
	HANDLE snapshotThread = CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD, PE32.th32ProcessID);
	if (snapshotThread == INVALID_HANDLE_VALUE)
	{
		CloseHandle(snapshotProcess);
		return false;
	}

	THREADENTRY32 TE32;
	TE32.dwSize = sizeof(THREADENTRY32);

	isExist = false;
	if (Thread32First(snapshotThread, &TE32))
	{
		do
		{
			if (TE32.th32OwnerProcessID == PE32.th32ProcessID)
			{
				//CloseHandle( snapshotThread );
				isExist = true;

				break;
			}
		} while (isExist == false && Thread32Next(snapshotThread, &TE32));
	}



	if (isExist == false)
	{
		CloseHandle(snapshotThread);
		CloseHandle(snapshotProcess);
		return false;
	}

	//
	// �ֱ�ͨ�� Id �ҵ�����, ��� processInfo, ������
	//    
	PROCESS_INFORMATION PI;

	PI.dwProcessId = PE32.th32ProcessID;
	PI.hProcess = OpenProcess(PROCESS_ALL_ACCESS, FALSE, PE32.th32ProcessID);
	if (PI.hProcess == NULL)
	{
		CloseHandle(snapshotThread);
		CloseHandle(snapshotProcess);
		return false;
	}

	PI.dwThreadId = TE32.th32ThreadID;
	PI.hThread = OpenThread(THREAD_ALL_ACCESS, FALSE, TE32.th32ThreadID);
	if (PI.hThread == NULL)
	{
		CloseHandle(PI.hProcess);
		CloseHandle(snapshotThread);
		CloseHandle(snapshotProcess);
		return false;
	}

	// ������ⲿ����, �򽫸ýṹ����һ���������ⲿ
	if (processInfo != NULL)
		memcpy((void *)processInfo, (const void *)&PI, sizeof(PROCESS_INFORMATION));

	CloseHandle(snapshotThread);
	CloseHandle(snapshotProcess);
	return true;
}

char * memmem(const char *target, unsigned long tlen, const char *search, unsigned long slen)
{
	char *p = NULL;
	unsigned long i = 0;
	char* q;
	for (p = (char*)target; p<(target + tlen); p++)
	{
		q = p;
		if (*p == search[0])
		{
			for (i = 0; (i<slen) && (*q == search[i]); i++)
			{
				q++;
				if (i == (slen - 1))
					return q - slen;
			}
		}
	}
	return NULL;
}


int EnableDebugPriv(const char * name)  //��������ΪDEBUGȨ��
{
	HANDLE hToken;
	TOKEN_PRIVILEGES tp;
	LUID luid;
	//�򿪽������ƻ�
	if (!OpenProcessToken(GetCurrentProcess(),
		TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY,
		&hToken))
	{
		printf("OpenProcessToken error\n");
		return 1;
	}
	//��ý��̱���ΨһID
	if (!LookupPrivilegeValue(NULL, name, &luid))
	{
		printf("LookupPrivilege error!\n");
	}
	tp.PrivilegeCount = 1;
	tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
	tp.Privileges[0].Luid = luid;
	//��������Ȩ��
	if (!AdjustTokenPrivileges(hToken, 0, &tp, sizeof(TOKEN_PRIVILEGES), NULL, NULL))
	{
		printf("AdjustTokenPrivileges error!\n");
		return 1;
	}
	return 0;
}



BOOL InjectDllHandle(const char *DllFullPath, HANDLE hProcessHandle)
{

	//��õ���Ȩ��
	if (EnableDebugPriv(SE_DEBUG_NAME))
	{
		printf("add privilege error");
		return FALSE;
	}

	char *pszLibFileRemote;
	//������dll�ļ�����·��
	pszLibFileRemote = (char *)VirtualAllocEx(hProcessHandle,
		NULL, lstrlen(DllFullPath) + 1,
		MEM_COMMIT, PAGE_EXECUTE_READWRITE);
	if (pszLibFileRemote == NULL)
	{
		printf("VirtualAllocEx error\n");
		return FALSE;
	}
	//��dll������·��д�뵽�ڴ棬
	if (WriteProcessMemory(hProcessHandle,
		pszLibFileRemote, (void *)DllFullPath, lstrlen(DllFullPath) + 1, NULL) == 0)
	{
		printf("WriteProcessMemory error\n");
		return FALSE;
	}

	LPVOID pFunc = LoadLibraryA;
	//�õ�LoadLibraryA������ַ
	PTHREAD_START_ROUTINE pfnStartAddr = (PTHREAD_START_ROUTINE)
		GetProcAddress(GetModuleHandle(TEXT("Kernel32")), "LoadLibraryA");
	if (pfnStartAddr == NULL)
	{
		printf("GetProcAddress error\n");
		return FALSE;
	}
	HANDLE hRemoteThread;
	//����Զ���߳�
	if ((hRemoteThread = CreateRemoteThread(hProcessHandle, NULL, 0,
		(PTHREAD_START_ROUTINE)pFunc, pszLibFileRemote, 0, NULL)) == NULL)
	{
		printf("CreateRemoteThread error\n");
		return FALSE;
	}
	return TRUE;
}


BOOL InjectDll(const char *DllFullPath, const DWORD dwRemoteProcessId)
{
	HANDLE hRemoteProcess;
	//��õ���Ȩ��
	if (EnableDebugPriv(SE_DEBUG_NAME))
	{
		printf("add privilege error");
		return FALSE;
	}
	//��Ŀ�����
	if ((hRemoteProcess = OpenProcess(PROCESS_ALL_ACCESS, FALSE, dwRemoteProcessId)) == NULL)
	{
		printf("OpenProcess error\n");
		return FALSE;
	}
	char *pszLibFileRemote;
	//������dll�ļ�����·��
	pszLibFileRemote = (char *)VirtualAllocEx(hRemoteProcess,
		NULL, lstrlen(DllFullPath) + 1,
		MEM_COMMIT, PAGE_EXECUTE_READWRITE);
	if (pszLibFileRemote == NULL)
	{
		printf("VirtualAllocEx error\n");
		return FALSE;
	}
	//��dll������·��д�뵽�ڴ棬
	if (WriteProcessMemory(hRemoteProcess,
		pszLibFileRemote, (void *)DllFullPath, lstrlen(DllFullPath) + 1, NULL) == 0)
	{
		printf("WriteProcessMemory error\n");
		return FALSE;
	}

	LPVOID pFunc = LoadLibraryA;
	//�õ�LoadLibraryA������ַ
	PTHREAD_START_ROUTINE pfnStartAddr = (PTHREAD_START_ROUTINE)
		GetProcAddress(GetModuleHandle(TEXT("Kernel32")), "LoadLibraryA");
	if (pfnStartAddr == NULL)
	{
		printf("GetProcAddress error\n");
		return FALSE;
	}
	HANDLE hRemoteThread;
	//����Զ���߳�
	if ((hRemoteThread = CreateRemoteThread(hRemoteProcess, NULL, 0,
		(PTHREAD_START_ROUTINE)pFunc, pszLibFileRemote, 0, NULL)) == NULL)
	{
		printf("CreateRemoteThread error\n");
		return FALSE;
	}
	return TRUE;
}



DWORD GetProcessID(char *ProcessName)
{
	PROCESSENTRY32 pe32;
	pe32.dwSize = sizeof(pe32);
	//���ϵͳ�����н��̿���
	HANDLE hProcessSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
	if (hProcessSnap == INVALID_HANDLE_VALUE)
	{
		printf("CreateToolhelp32Snapshot error");
		return 0;
	}
	//ö���б��еĵ�һ������
	BOOL bProcess = Process32First(hProcessSnap, &pe32);
	while (bProcess)
	{
		//�Ƚ��ҵ��Ľ�����������Ҫ���ҵĽ�������һ���򷵻ؽ���id
		if (stricmp(pe32.szExeFile, ProcessName) == 0)
			return pe32.th32ProcessID;
		//��������
		bProcess = Process32Next(hProcessSnap, &pe32);
	}
	CloseHandle(hProcessSnap);
	return 0;
}
