/*
  ==============================================================================

    This file was auto-generated!

  ==============================================================================
*/

#include "MainComponent.h"


//==============================================================================
MainContentComponent::MainContentComponent() :currentIndex(-1)
{
    setSize (600, 400);

	_listBox.setModel(this);

	_listBox.setName("_listBox");
	addAndMakeVisible(_listBox);
	currentDemo = nullptr;
}

MainContentComponent::~MainContentComponent()
{
	currentDemo = nullptr;
}

void MainContentComponent::paint (Graphics& g)
{
    // (Our component is opaque, so we must completely fill the background with a solid colour)
    g.fillAll (getLookAndFeel().findColour (ResizableWindow::backgroundColourId));

    g.setFont (Font (16.0f));
    g.setColour (Colours::white);
    g.drawText ("choose an game to start!", getLocalBounds(), Justification::centred, true);
}

void MainContentComponent::resized()
{
    // This is called when the MainContentComponent is resized.
    // If you add any child components, this is where you should
    // update their positions.

	auto r = getLocalBounds();
	int listBoxWidth = roundToInt(proportionOfWidth(0.2000f));
	_listBox.setBounds(r.removeFromLeft(listBoxWidth));

	FlexBox masterbox;
	masterbox.flexDirection = FlexBox::Direction::column;// column;// : FlexBox::Direction::row;
	masterbox.alignItems = FlexBox::AlignItems::stretch;
	masterbox.alignContent = FlexBox::AlignContent::stretch;
	masterbox.flexWrap = juce::FlexBox::Wrap::wrap;
	masterbox.justifyContent = FlexBox::JustifyContent::center;



	int num = getNumChildComponents();
	for (auto i = 0; i < num; i++)
	{
		auto c = getChildComponent(i);
		if (c->getName() == "_listBox")
			continue;
		if (c)
		{
			masterbox.items.add(FlexItem(1, 1).withFlex(1).withMargin(10));
			auto& flexitem = masterbox.items.getReference(masterbox.items.size() - 1);
			flexitem.associatedComponent = c;
		}
	}
	//Rectangle<float> r = getLocalBounds().toFloat();
	//r.reduce(10.0f, 10.0f);
	masterbox.performLayout(r);
}
